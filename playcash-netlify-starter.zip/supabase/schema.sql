-- PlayCash starter schema for Supabase.
-- Run in Supabase SQL Editor after creating a new project.
-- IMPORTANT: Test on a new project before using with real users or money.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 24),
  referral_code text not null unique default upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8)),
  referred_by uuid references public.profiles(id),
  last_checkin_date date,
  created_at timestamptz not null default now()
);

create table if not exists public.wallet_accounts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  available_cents bigint not null default 0 check (available_cents >= 0),
  pending_cents bigint not null default 0 check (pending_cents >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  transaction_type text not null,
  amount_cents bigint not null,
  description text not null,
  reference_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.game_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  game_type text not null check (game_type in ('candy_match','gold_mining')),
  score integer not null default 0,
  reward_cents bigint not null default 0,
  status text not null default 'submitted' check (status in ('submitted','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  reward_cents bigint not null default 0 check (reward_cents >= 0),
  is_active boolean not null default true,
  daily_limit integer not null default 1 check (daily_limit > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.task_completions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  completed_on date not null default current_date,
  created_at timestamptz not null default now(),
  unique(user_id, task_id, completed_on)
);

create table if not exists public.daily_checkins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  checkin_date date not null default current_date,
  reward_cents bigint not null default 0,
  created_at timestamptz not null default now(),
  unique(user_id, checkin_date)
);

create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles(id) on delete cascade,
  referred_user_id uuid not null unique references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','eligible','rewarded','rejected')),
  reward_cents bigint not null default 0,
  created_at timestamptz not null default now(),
  check (referrer_id <> referred_user_id)
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount_cents bigint not null check (amount_cents >= 20000),
  payout_method text not null check (payout_method in ('Bank transfer','PayPal','OPay','PalmPay','Cryptocurrency')),
  payment_details text not null,
  status text not null default 'pending' check (status in ('pending','under_review','approved','processing','paid','rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  admin_user_id uuid not null references auth.users(id),
  action text not null,
  target_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.platform_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

insert into public.platform_settings(key, value)
values
  ('daily_checkin_reward_cents', '0'::jsonb),
  ('candy_match_reward_cents', '0'::jsonb),
  ('gold_mining_reward_cents', '0'::jsonb),
  ('referral_reward_cents', '0'::jsonb),
  ('reward_budget_enabled', 'false'::jsonb)
on conflict (key) do nothing;

-- Automatically create a profile and zero-balance wallet after auth signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  desired_username text;
begin
  desired_username := coalesce(
    nullif(trim(new.raw_user_meta_data ->> 'username'), ''),
    'player_' || substr(replace(new.id::text, '-', ''), 1, 10)
  );

  insert into public.profiles(id, username)
  values (new.id, desired_username)
  on conflict (id) do nothing;

  insert into public.wallet_accounts(user_id)
  values (new.id)
  on conflict (user_id) do nothing;

  if nullif(new.raw_user_meta_data ->> 'referral_code', '') is not null then
    insert into public.referrals(referrer_id, referred_user_id)
    select p.id, new.id
    from public.profiles p
    where p.referral_code = upper(new.raw_user_meta_data ->> 'referral_code')
      and p.id <> new.id
    on conflict (referred_user_id) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Check-in reward defaults to $0 until an administrator configures and funds rewards.
create or replace function public.claim_daily_checkin()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  reward bigint := 0;
begin
  if uid is null then raise exception 'Please sign in first.'; end if;

  if exists(select 1 from public.daily_checkins where user_id = uid and checkin_date = current_date) then
    raise exception 'You have already checked in today.';
  end if;

  select coalesce((value #>> '{}')::bigint, 0) into reward
  from public.platform_settings where key = 'daily_checkin_reward_cents';

  if not exists(select 1 from public.platform_settings where key = 'reward_budget_enabled' and value = 'true'::jsonb) then
    reward := 0;
  end if;

  insert into public.daily_checkins(user_id, checkin_date, reward_cents)
  values (uid, current_date, reward);

  update public.profiles set last_checkin_date = current_date where id = uid;

  if reward > 0 then
    update public.wallet_accounts set available_cents = available_cents + reward, updated_at = now() where user_id = uid;
    insert into public.wallet_transactions(user_id, transaction_type, amount_cents, description)
    values (uid, 'daily_checkin', reward, 'Daily check-in reward');
  end if;

  return jsonb_build_object('message', case when reward > 0 then 'Daily check-in claimed.' else 'Check-in recorded. Cash rewards are not enabled yet.' end);
end;
$$;

-- Starter guardrail: game rewards remain $0 until a proper authoritative game validator
-- and funded reward budget are implemented. Do not trust client-provided scores for cash.
create or replace function public.claim_game_reward(p_game_type text, p_score integer)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'Please sign in first.'; end if;
  if p_game_type not in ('candy_match','gold_mining') then raise exception 'Unknown game type.'; end if;
  if p_score < 0 or p_score > 1000000 then raise exception 'Invalid score.'; end if;

  insert into public.game_sessions(user_id, game_type, score, reward_cents, status)
  values (uid, p_game_type, p_score, 0, 'submitted');

  return jsonb_build_object('message', 'Game result recorded for review. No cash reward was issued by this demo function.');
end;
$$;

create or replace function public.request_withdrawal(
  p_amount_cents bigint,
  p_method text,
  p_payment_details text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  new_id uuid;
begin
  if uid is null then raise exception 'Please sign in first.'; end if;
  if p_amount_cents < 20000 then raise exception 'Minimum withdrawal is $200.'; end if;
  if p_method not in ('Bank transfer','PayPal','OPay','PalmPay','Cryptocurrency') then raise exception 'Unsupported payout method.'; end if;
  if length(trim(coalesce(p_payment_details,''))) < 4 or length(p_payment_details) > 1000 then raise exception 'Please provide valid payout details.'; end if;

  update public.wallet_accounts
  set available_cents = available_cents - p_amount_cents,
      pending_cents = pending_cents + p_amount_cents,
      updated_at = now()
  where user_id = uid and available_cents >= p_amount_cents;

  if not found then raise exception 'Insufficient available balance.'; end if;

  insert into public.withdrawal_requests(user_id, amount_cents, payout_method, payment_details)
  values (uid, p_amount_cents, p_method, trim(p_payment_details))
  returning id into new_id;

  insert into public.wallet_transactions(user_id, transaction_type, amount_cents, description, reference_id)
  values (uid, 'withdrawal_pending', -p_amount_cents, 'Withdrawal request submitted', new_id);

  return jsonb_build_object('message', 'Withdrawal request submitted for review.', 'request_id', new_id);
end;
$$;

create or replace function public.admin_update_withdrawal(p_withdrawal_id uuid, p_status text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  admin_uid uuid := auth.uid();
  req public.withdrawal_requests%rowtype;
begin
  if admin_uid is null or not exists(select 1 from public.admin_users where user_id = admin_uid) then
    raise exception 'Administrator access required.';
  end if;
  if p_status not in ('approved','rejected','processing','paid','under_review') then
    raise exception 'Invalid status.';
  end if;

  select * into req from public.withdrawal_requests where id = p_withdrawal_id for update;
  if not found then raise exception 'Withdrawal request not found.'; end if;

  if req.status = 'paid' or req.status = 'rejected' then
    raise exception 'This request is already closed.';
  end if;

  if p_status = 'paid' and req.status <> 'processing' then
    raise exception 'Mark as paid only after the request is processing and payment is confirmed.';
  end if;

  if p_status = 'rejected' then
    update public.wallet_accounts
      set pending_cents = greatest(0, pending_cents - req.amount_cents),
          available_cents = available_cents + req.amount_cents,
          updated_at = now()
      where user_id = req.user_id;
    insert into public.wallet_transactions(user_id, transaction_type, amount_cents, description, reference_id)
      values (req.user_id, 'withdrawal_refund', req.amount_cents, 'Rejected withdrawal returned to balance', req.id);
  elsif p_status = 'paid' then
    update public.wallet_accounts
      set pending_cents = greatest(0, pending_cents - req.amount_cents), updated_at = now()
      where user_id = req.user_id;
  end if;

  update public.withdrawal_requests set status = p_status, updated_at = now() where id = req.id;
  insert into public.admin_audit_logs(admin_user_id, action, target_id, details)
    values (admin_uid, 'withdrawal_status_changed', req.id, jsonb_build_object('from', req.status, 'to', p_status));

  return jsonb_build_object('message', 'Withdrawal status updated.');
end;
$$;

-- RLS
alter table public.profiles enable row level security;
alter table public.wallet_accounts enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.game_sessions enable row level security;
alter table public.tasks enable row level security;
alter table public.task_completions enable row level security;
alter table public.daily_checkins enable row level security;
alter table public.referrals enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.admin_users enable row level security;
alter table public.admin_audit_logs enable row level security;
alter table public.platform_settings enable row level security;

drop policy if exists "profiles own read" on public.profiles;
create policy "profiles own read" on public.profiles for select to authenticated using (id = auth.uid());
drop policy if exists "profiles own update" on public.profiles;
create policy "profiles own update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "wallet own read" on public.wallet_accounts;
create policy "wallet own read" on public.wallet_accounts for select to authenticated using (user_id = auth.uid());
drop policy if exists "transactions own read" on public.wallet_transactions;
create policy "transactions own read" on public.wallet_transactions for select to authenticated using (user_id = auth.uid());
drop policy if exists "game sessions own read" on public.game_sessions;
create policy "game sessions own read" on public.game_sessions for select to authenticated using (user_id = auth.uid());

drop policy if exists "active tasks read" on public.tasks;
create policy "active tasks read" on public.tasks for select to authenticated using (is_active = true);

drop policy if exists "task completions own read" on public.task_completions;
create policy "task completions own read" on public.task_completions for select to authenticated using (user_id = auth.uid());
drop policy if exists "checkins own read" on public.daily_checkins;
create policy "checkins own read" on public.daily_checkins for select to authenticated using (user_id = auth.uid());
drop policy if exists "referrals own read" on public.referrals;
create policy "referrals own read" on public.referrals for select to authenticated using (referrer_id = auth.uid() or referred_user_id = auth.uid());

drop policy if exists "withdrawals own read" on public.withdrawal_requests;
create policy "withdrawals own read" on public.withdrawal_requests for select to authenticated using (user_id = auth.uid());
drop policy if exists "admin users own read" on public.admin_users;
create policy "admin users own read" on public.admin_users for select to authenticated using (user_id = auth.uid());
drop policy if exists "admin audit admin read" on public.admin_audit_logs;
create policy "admin audit admin read" on public.admin_audit_logs for select to authenticated using (exists(select 1 from public.admin_users where user_id = auth.uid()));
drop policy if exists "platform settings authenticated read" on public.platform_settings;
create policy "platform settings authenticated read" on public.platform_settings for select to authenticated using (true);

grant execute on function public.claim_daily_checkin() to authenticated;
grant execute on function public.claim_game_reward(text, integer) to authenticated;
grant execute on function public.request_withdrawal(bigint, text, text) to authenticated;
grant execute on function public.admin_update_withdrawal(uuid, text) to authenticated;

-- After you sign up your own account, grant admin access manually in SQL Editor:
-- insert into public.admin_users(user_id)
-- select id from auth.users where email = 'YOUR-LOGIN-EMAIL';
