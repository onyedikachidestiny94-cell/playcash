# PlayCash — Netlify starter

This is a React + Vite starter project designed for Netlify hosting and Supabase authentication/database.

## Included

- Responsive mobile/desktop UI
- Signup/login UI using Supabase Auth
- User dashboard, games hub, daily tasks, referrals, wallet and withdrawal request screens
- Admin withdrawal review screen gated by a database admin role
- Supabase SQL schema with RLS and server-side RPCs
- Netlify build configuration

## Important starter limitations

This is a starter implementation, not a production-ready real-money rewards business:
- Candy Match, Gold Miner, and Spin Wheel screens currently contain demo interactions. They are not finished production games.
- Game reward RPC records a result with **$0 reward** and explicitly does not trust a client score for money.
- Daily check-in is recorded, but cash reward is $0 until an admin configures reward funding and enables the reward budget.
- Referral reward crediting is not yet implemented.
- Withdrawal requests are stored and can be reviewed by an authorized admin; there is no automatic payout integration.
- Do not promise earnings or make rewards withdrawable until your business has reliable funding, fraud controls, provider approval, and applicable legal/compliance review.
- Payout details are sensitive personal data. Before production, consider encrypting or tokenizing them, restricting access, and adding retention/deletion policies.

## 1. Create Supabase project

1. Create a project at https://supabase.com/
2. Open **SQL Editor**.
3. Run all of `supabase/schema.sql`.
4. In **Authentication → Providers → Email**, turn off **Confirm email** if you want email/password accounts to log in without email verification. You still need a valid email as the username for this starter's auth form. A true username-only auth flow needs a separate server-side design.
5. In **Project Settings → API**, copy the Project URL and the publishable/anon key.

## 2. Configure environment variables

Copy `.env.example` to `.env.local` for local development and fill in your Supabase values:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

Never put a Supabase `service_role` key in frontend code or Netlify's `VITE_` variables.

## 3. Grant your own account admin access

After you create your account, run this in Supabase SQL Editor, replacing the email with your login email:

```sql
insert into public.admin_users(user_id)
select id from auth.users where email = 'YOUR-LOGIN-EMAIL'
on conflict do nothing;
```

Reload or sign out and back in. Admin privileges are checked by the database.

## 4. Publish to Netlify

### Easiest route: GitHub

1. Create a GitHub account/repository and upload these project files.
2. In Netlify, choose **Add new site → Import an existing project**.
3. Connect GitHub and choose the repository.
4. Build command: `npm run build`
5. Publish directory: `dist`
6. Add these environment variables in Netlify site configuration:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
7. Deploy the site.

You can also use Netlify's manual deploy by building the project first and uploading the generated `dist` folder. Git-based deploy is easier for updates.

## 5. Test before launch

- Create a test account and check that a profile and wallet are created.
- Confirm login works with email confirmation disabled in Supabase.
- Test RLS: one user must not read another user's wallet or withdrawal records.
- Test withdrawal requests with a test balance only in a non-production test project.
- Verify the admin account can review requests and regular users cannot.
- Never add fake balances to real user accounts.
- Do not enter real bank details, PayPal details, or crypto wallet secrets into a demo site.

## Known product choice

The interface uses email + password because Supabase's standard password auth expects an email or phone identifier. Email confirmation can be disabled, so no verification link is required, but this starter does not yet support username-only login.
