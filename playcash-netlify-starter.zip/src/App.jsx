import React, { useEffect, useMemo, useState } from "react";
import {
  Gamepad2, Wallet, Users, Gift, Trophy, CircleDollarSign, Flame, Pickaxe,
  Candy, CalendarCheck, Settings, LogOut, Menu, X, ArrowDownToLine,
  Copy, Check, Sparkles, ShieldCheck, Clock3, ChevronRight, Coins, RotateCw,
  LockKeyhole, Mail, UserRound, Eye, EyeOff, History, CircleHelp, ExternalLink
} from "lucide-react";
import { supabase, supabaseConfigured } from "./supabase";

const money = (n) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(n || 0));
const nav = [
  ["Overview", "overview", Gamepad2],
  ["Play games", "games", Candy],
  ["Daily tasks", "tasks", CalendarCheck],
  ["Referrals", "referrals", Users],
  ["Wallet", "wallet", Wallet],
  ["Withdraw", "withdraw", ArrowDownToLine],
];

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [page, setPage] = useState("overview");
  const [authMode, setAuthMode] = useState("signup");
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState("");
  const [notice, setNotice] = useState("");
  const [mobileNav, setMobileNav] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [referralCount, setReferralCount] = useState(0);
  const [amount, setAmount] = useState("200");
  const [method, setMethod] = useState("Bank transfer");
  const [paymentDetails, setPaymentDetails] = useState("");
  const [checkinClaimed, setCheckinClaimed] = useState(false);
  const [gameScore, setGameScore] = useState(0);
  const [gamePlays, setGamePlays] = useState(0);
  const [spinResult, setSpinResult] = useState(null);
  const [spinning, setSpinning] = useState(false);
  const [mining, setMining] = useState(0);
  const [candy, setCandy] = useState(Array.from({ length: 36 }, () => Math.floor(Math.random() * 5)));
  const [adminRows, setAdminRows] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (!supabaseConfigured) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session?.user) loadUserData();
    else {
      setProfile(null); setBalance(0); setTransactions([]); setWithdrawals([]);
      setReferralCount(0); setIsAdmin(false);
    }
  }, [session?.user?.id]);

  async function loadUserData() {
    if (!supabase || !session?.user) return;
    const uid = session.user.id;
    const [{ data: p }, { data: w }, { data: tx }, { data: wd }, { count: refs }, { data: admin }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", uid).maybeSingle(),
      supabase.from("wallet_accounts").select("available_cents,pending_cents").eq("user_id", uid).maybeSingle(),
      supabase.from("wallet_transactions").select("*").eq("user_id", uid).order("created_at", { ascending: false }).limit(8),
      supabase.from("withdrawal_requests").select("*").eq("user_id", uid).order("created_at", { ascending: false }).limit(8),
      supabase.from("referrals").select("*", { count: "exact", head: true }).eq("referrer_id", uid),
      supabase.from("admin_users").select("user_id").eq("user_id", uid).maybeSingle()
    ]);
    setProfile(p || null);
    setBalance((w?.available_cents || 0) / 100);
    setTransactions(tx || []);
    setWithdrawals(wd || []);
    setReferralCount(refs || 0);
    setIsAdmin(Boolean(admin));
    setCheckinClaimed(Boolean(p?.last_checkin_date === new Date().toISOString().slice(0, 10)));
  }

  async function handleAuth(e) {
    e.preventDefault(); setAuthBusy(true); setAuthError(""); setNotice("");
    if (!supabaseConfigured) {
      setAuthError("Connect Supabase first. Follow SETUP.md in the downloaded project.");
      setAuthBusy(false); return;
    }
    try {
      if (authMode === "signup") {
        if (!username.trim()) throw new Error("Please choose a username.");
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { username: username.trim() }, emailRedirectTo: undefined }
        });
        if (error) throw error;
        if (data.session) setNotice("Account created. Welcome to PlayCash!");
        else setNotice("Account created. If Supabase still asks for email confirmation, turn off Confirm email in Supabase Auth settings.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
      }
    } catch (err) { setAuthError(err.message || "Unable to authenticate."); }
    finally { setAuthBusy(false); }
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setPage("overview"); setNotice("You have signed out.");
  }

  async function claimCheckin() {
    if (!supabase) return;
    setNotice(""); 
    const { data, error } = await supabase.rpc("claim_daily_checkin");
    if (error) setNotice(error.message);
    else { setNotice(data?.message || "Daily check-in processed."); await loadUserData(); }
  }

  async function claimGameReward(gameType, score) {
    if (!supabase) { setNotice("Connect Supabase to save rewards."); return; }
    const { data, error } = await supabase.rpc("claim_game_reward", { p_game_type: gameType, p_score: score });
    if (error) setNotice(error.message);
    else { setNotice(data?.message || "Game result submitted."); await loadUserData(); }
  }

  async function submitWithdrawal(e) {
    e.preventDefault(); setNotice("");
    const dollars = Number(amount);
    if (!Number.isFinite(dollars) || dollars < 200) { setNotice("The minimum withdrawal is $200."); return; }
    if (!paymentDetails.trim()) { setNotice("Enter the payout details required for your selected method."); return; }
    const { data, error } = await supabase.rpc("request_withdrawal", {
      p_amount_cents: Math.round(dollars * 100),
      p_method: method,
      p_payment_details: paymentDetails.trim()
    });
    if (error) setNotice(error.message);
    else { setNotice(data?.message || "Withdrawal request submitted for review."); setPaymentDetails(""); await loadUserData(); }
  }

  async function loadAdminRows() {
    if (!supabase) return;
    const { data, error } = await supabase.from("withdrawal_requests").select("*").order("created_at", { ascending: false }).limit(100);
    if (error) setNotice(error.message); else setAdminRows(data || []);
  }

  async function updateWithdrawal(id, status) {
    const { data, error } = await supabase.rpc("admin_update_withdrawal", { p_withdrawal_id: id, p_status: status });
    if (error) setNotice(error.message);
    else { setNotice(data?.message || "Withdrawal updated."); loadAdminRows(); await loadUserData(); }
  }

  const referralLink = useMemo(() => profile?.referral_code ? `${window.location.origin}/?ref=${profile.referral_code}` : "", [profile?.referral_code]);
  function copy(text) {
    navigator.clipboard?.writeText(text).then(() => setNotice("Copied to clipboard.")).catch(() => setNotice(text));
  }

  function playCandy() {
    const next = Array.from({ length: 36 }, () => Math.floor(Math.random() * 5));
    setCandy(next);
    const score = Math.floor(100 + Math.random() * 500);
    setGameScore(score); setGamePlays(p => p + 1);
    setNotice("Demo round complete. Rewards are only credited after the server validates eligible gameplay.");
  }
  function spin() {
    if (spinning) return;
    setSpinning(true); setSpinResult(null);
    setTimeout(() => { const prizes = ["Try again", "Bonus points", "Gold dust", "Daily bonus"]; setSpinResult(prizes[Math.floor(Math.random() * prizes.length)]); setSpinning(false); }, 1800);
  }

  if (!session) return <AuthScreen
    authMode={authMode} setAuthMode={setAuthMode} email={email} setEmail={setEmail}
    password={password} setPassword={setPassword} username={username} setUsername={setUsername}
    showPassword={showPassword} setShowPassword={setShowPassword} handleAuth={handleAuth}
    authBusy={authBusy} authError={authError} notice={notice}
  />;

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand"><span className="brand-mark"><Sparkles size={20}/></span><span>play<span className="brand-green">cash</span></span><button className="icon-btn mobile-close" onClick={() => setMobileNav(false)}><X size={20}/></button></div>
        <div className="side-label">WORKSPACE</div>
        <nav>{nav.map(([label, key, Icon]) => <button key={key} className={`nav-item ${page === key ? "active" : ""}`} onClick={() => { setPage(key); setMobileNav(false); }}><Icon size={18}/><span>{label}</span>{key === "withdraw" && <span className="nav-dot"/>}</button>)}</nav>
        {isAdmin && <><div className="side-label">MANAGEMENT</div><button className={`nav-item ${page === "admin" ? "active" : ""}`} onClick={() => {setPage("admin"); setMobileNav(false); loadAdminRows();}}><ShieldCheck size={18}/><span>Admin panel</span></button></>}
        <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><CircleHelp size={17}/></div><b>Need help?</b><p>Visit our help center for account and rewards support.</p><button onClick={() => setNotice("Help center: add your support email before launch.")}>Get support <ChevronRight size={14}/></button></div><button className="nav-item signout" onClick={signOut}><LogOut size={18}/><span>Sign out</span></button></div>
      </aside>
      {mobileNav && <div className="overlay" onClick={() => setMobileNav(false)}/>}
      <main className="main-area">
        <header className="topbar"><button className="icon-btn mobile-menu" onClick={() => setMobileNav(true)}><Menu size={21}/></button><div className="breadcrumb">Workspace <ChevronRight size={14}/> <b>{nav.find(x => x[1] === page)?.[0] || (page === "admin" ? "Admin panel" : "Games")}</b></div><div className="top-actions"><span className="live-pill"><span/> Rewards hub</span><button className="avatar" title={profile?.username || "Account"}>{(profile?.username || session.user.email || "P").slice(0,1).toUpperCase()}</button></div></header>
        <div className="content">
          {notice && <div className="notice"><span>{notice}</span><button onClick={() => setNotice("")}><X size={16}/></button></div>}
          {page === "overview" && <Overview profile={profile} balance={balance} transactions={transactions} referralCount={referralCount} setPage={setPage} checkinClaimed={checkinClaimed} claimCheckin={claimCheckin} />}
          {page === "games" && <Games candy={candy} playCandy={playCandy} gameScore={gameScore} gamePlays={gamePlays} spin={spin} spinning={spinning} spinResult={spinResult} mining={mining} setMining={setMining} claimGameReward={claimGameReward} />}
          {page === "tasks" && <Tasks checkinClaimed={checkinClaimed} claimCheckin={claimCheckin} setPage={setPage} />}
          {page === "referrals" && <Referrals referralLink={referralLink} referralCount={referralCount} copy={copy} />}
          {page === "wallet" && <WalletPage balance={balance} transactions={transactions} withdrawals={withdrawals} setPage={setPage} />}
          {page === "withdraw" && <WithdrawPage balance={balance} amount={amount} setAmount={setAmount} method={method} setMethod={setMethod} paymentDetails={paymentDetails} setPaymentDetails={setPaymentDetails} submitWithdrawal={submitWithdrawal} withdrawals={withdrawals} />}
          {page === "admin" && <AdminPage rows={adminRows} reload={loadAdminRows} updateWithdrawal={updateWithdrawal} isAdmin={isAdmin} />}
        </div>
        <footer className="footer"><span>© {new Date().getFullYear()} PlayCash</span><span>Play responsibly · Rewards subject to eligibility</span></footer>
      </main>
    </div>
  );
}

function AuthScreen(props) {
  const { authMode, setAuthMode, email, setEmail, password, setPassword, username, setUsername, showPassword, setShowPassword, handleAuth, authBusy, authError, notice } = props;
  return <div className="auth-page"><div className="auth-art"><div className="art-orb orb-one"/><div className="art-orb orb-two"/><div className="art-content"><div className="brand light"><span className="brand-mark"><Sparkles size={20}/></span><span>play<span className="brand-green">cash</span></span></div><div className="art-chip"><Sparkles size={14}/> YOUR DAILY REWARDS HUB</div><h1>Play more.<br/><span>Unlock rewards.</span></h1><p>Games, daily missions, and a little friendly competition — all in one place.</p><div className="art-stats"><div><b>01</b><span>Play games</span></div><div><b>02</b><span>Complete tasks</span></div><div><b>03</b><span>Track rewards</span></div></div><div className="floating-coins"><span>✦</span><span>$</span><span>✧</span></div></div><div className="art-foot"><ShieldCheck size={15}/> Secure account access</div></div><div className="auth-panel"><div className="auth-card"><div className="mobile-brand brand"><span className="brand-mark"><Sparkles size={20}/></span><span>play<span className="brand-green">cash</span></span></div><div className="eyebrow">WELCOME TO PLAYCASH</div><h2>{authMode === "signup" ? "Create your account" : "Welcome back"}</h2><p className="muted">{authMode === "signup" ? "Join the fun and start your rewards journey." : "Sign in to continue to your dashboard."}</p>{!supabaseConfigured && <div className="setup-warning"><LockKeyhole size={17}/><span><b>Backend setup required</b><br/>Add your Supabase URL and publishable key to enable real accounts.</span></div>}{authError && <div className="error-box">{authError}</div>}{notice && <div className="success-box">{notice}</div>}<form onSubmit={handleAuth} className="auth-form">{authMode === "signup" && <label>Username<div className="field"><UserRound size={17}/><input value={username} onChange={e => setUsername(e.target.value)} placeholder="Choose a username" minLength={3} maxLength={24} required/></div></label>}<label>Email address<div className="field"><Mail size={17}/><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required/></div></label><label>Password<div className="field"><LockKeyhole size={17}/><input type={showPassword ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters" minLength={8} autoComplete={authMode === "signup" ? "new-password" : "current-password"} required/><button type="button" className="field-action" onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div></label><button className="primary-btn full" disabled={authBusy}>{authBusy ? "Please wait..." : authMode === "signup" ? "Create account" : "Sign in"}<ChevronRight size={17}/></button></form><div className="auth-switch">{authMode === "signup" ? "Already have an account?" : "New to PlayCash?"} <button onClick={() => setAuthMode(authMode === "signup" ? "login" : "signup")}>{authMode === "signup" ? "Sign in" : "Create account"}</button></div><div className="auth-legal">By continuing, you agree to our <a href="#terms">Terms</a> and <a href="#privacy">Privacy Policy</a>.</div><div className="auth-foot"><ShieldCheck size={15}/> Your account is protected by secure authentication.</div></div></div></div>;
}

function PageHeading({ eyebrow, title, description, action }) { return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>; }
function Overview({ profile, balance, transactions, referralCount, setPage, checkinClaimed, claimCheckin }) {
  return <><PageHeading eyebrow="YOUR SPACE" title={`Good to see you${profile?.username ? `, ${profile.username}` : ""}!`} description="Your games, tasks, and rewards — all in one place." action={<div className="date-chip"><CalendarCheck size={16}/> Daily rewards</div>}/>
    <section className="hero-card"><div className="hero-copy"><div className="hero-badge"><Sparkles size={13}/> YOUR REWARDS OVERVIEW</div><h2>Every little win<br/>adds up.</h2><p>Play games, keep your streak going, and explore today's challenges.</p><div className="hero-actions"><button className="white-btn" onClick={() => setPage("games")}>Explore games <ChevronRight size={16}/></button><button className="ghost-light" onClick={() => setPage("tasks")}>View daily tasks</button></div></div><div className="hero-visual"><div className="coin coin-a">$</div><div className="coin coin-b">✦</div><div className="coin coin-c">★</div><div className="hero-wallet"><div className="wallet-top"><span>AVAILABLE BALANCE</span><Wallet size={19}/></div><strong>{money(balance)}</strong><div className="wallet-bottom"><span><span className="status-dot"/> Wallet connected</span><span>USD</span></div></div><div className="hero-spark">✦</div></div></section>
    <div className="stat-grid"><Stat icon={Wallet} label="Available balance" value={money(balance)} sub="Withdrawable rewards" color="green"/><Stat icon={Trophy} label="Lifetime earnings" value={money(balance)} sub="Wallet ledger total" color="gold"/><Stat icon={Users} label="Your referrals" value={referralCount} sub="Invited accounts" color="purple"/><Stat icon={Flame} label="Daily streak" value="Keep it up" sub="Check in each day" color="orange"/></div>
    <div className="section-title"><div><h2>Jump back in</h2><p>Pick up a game or complete a quick task.</p></div><button className="text-btn" onClick={() => setPage("games")}>All games <ChevronRight size={15}/></button></div>
    <div className="feature-grid"><FeatureCard icon={Candy} tone="pink" title="Candy Match" text="Match colorful candies and beat your best score." tag="PUZZLE" onClick={() => setPage("games")}/><FeatureCard icon={Pickaxe} tone="gold" title="Gold Miner" text="Dig for virtual gold and complete mining missions." tag="CASUAL" onClick={() => setPage("games")}/><FeatureCard icon={RotateCw} tone="purple" title="Daily Spin" text="Try your luck with today's reward wheel." tag="DAILY" onClick={() => setPage("games")}/></div>
    <div className="bottom-grid"><section className="panel"><div className="panel-heading"><div><h3>Daily check-in</h3><p>A quick visit keeps your routine going.</p></div><span className="panel-icon green"><CalendarCheck size={18}/></span></div><div className="checkin-strip">{["M","T","W","T","F","S","S"].map((d,i)=><div className={`day ${i===new Date().getDay()-1?"today":""}`} key={i}><span>{d}</span><b>{i+1}</b></div>)}</div><button className="primary-btn full" onClick={claimCheckin} disabled={checkinClaimed}>{checkinClaimed ? <><Check size={16}/> Checked in today</> : <>Claim daily check-in <ChevronRight size={16}/></>}</button><p className="tiny-note">Rewards depend on eligibility and configured reward rules.</p></section><section className="panel"><div className="panel-heading"><div><h3>Recent activity</h3><p>Your latest wallet transactions.</p></div><button className="icon-btn" onClick={() => setPage("wallet")}><History size={17}/></button></div>{transactions.length ? <div className="activity-list">{transactions.slice(0,4).map(tx=><div className="activity-row" key={tx.id}><div className="activity-icon"><Coins size={17}/></div><div className="activity-info"><b>{tx.description || tx.transaction_type || "Wallet activity"}</b><span>{new Date(tx.created_at).toLocaleDateString()}</span></div><strong className={tx.amount_cents > 0 ? "positive" : ""}>{money(tx.amount_cents/100)}</strong></div>)}</div> : <div className="empty-state"><History size={25}/><b>No activity yet</b><span>Your rewards and transactions will appear here.</span></div>}</section></div>
  </>;
}
function Stat({ icon: Icon, label, value, sub, color }) { return <div className="stat-card"><div className={`stat-icon ${color}`}><Icon size={19}/></div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-sub">{sub}</div></div>; }
function FeatureCard({ icon: Icon, tone, title, text, tag, onClick }) { return <button className="feature-card" onClick={onClick}><div className="feature-top"><span className={`feature-icon ${tone}`}><Icon size={24}/></span><span className="tag">{tag}</span></div><h3>{title}</h3><p>{text}</p><span className="feature-link">Play now <ChevronRight size={15}/></span></button>; }

function Games({ candy, playCandy, gameScore, gamePlays, spin, spinning, spinResult, mining, setMining, claimGameReward }) {
  const colors = ["#fb7185", "#fbbf24", "#60a5fa", "#a78bfa", "#34d399"];
  return <><PageHeading eyebrow="GAME LOUNGE" title="Pick your next game" description="Play quick casual games and work through eligible challenges."/><div className="games-grid"><section className="game-panel candy-panel"><div className="game-panel-top"><span className="feature-icon pink"><Candy size={23}/></span><span className="tag">MATCH 3</span></div><h2>Candy Match</h2><p>Swap and match candies to make a high score. This starter version demonstrates the game screen; full match validation can be added next.</p><div className="candy-board">{candy.map((c,i)=><button aria-label={`Candy ${i+1}`} key={i} style={{background: colors[c], transform: `rotate(${(i%3-1)*5}deg)`}} onClick={() => {}}>{["●","◆","✦","●","♥"][c]}</button>)}</div><div className="game-score"><span>Last score <b>{gameScore || "—"}</b></span><span>Rounds <b>{gamePlays}</b></span></div><button className="primary-btn full" onClick={playCandy}>Start demo round <ChevronRight size={16}/></button><button className="outline-btn full" onClick={() => claimGameReward("candy_match", gameScore || 100)}>Submit eligible score</button></section>
  <section className="game-panel miner-panel"><div className="game-panel-top"><span className="feature-icon gold"><Pickaxe size={23}/></span><span className="tag">CASUAL</span></div><h2>Gold Miner</h2><p>Tap to collect virtual gold and track your progress through the mining challenge.</p><div className="mine-scene"><div className="mine-sun">☼</div><div className="mountain mountain-back"/><div className="mountain mountain-front"/><div className="mine-gold">✦</div><div className="mine-cart">▰</div></div><div className="mining-counter"><span>Virtual gold collected</span><b><Coins size={17}/> {mining}</b></div><button className="primary-btn full" onClick={() => setMining(n=>n+1)}><Pickaxe size={16}/> Mine gold</button><button className="outline-btn full" onClick={() => claimGameReward("gold_mining", mining)}>Submit eligible progress</button></section>
  <section className="game-panel spin-panel"><div className="game-panel-top"><span className="feature-icon purple"><RotateCw size={23}/></span><span className="tag">DAILY</span></div><h2>Daily Spin</h2><p>Try the reward wheel. Production reward outcomes must be generated and validated by the server.</p><div className={`spin-wheel ${spinning ? "spinning" : ""}`}><div className="wheel-inner"><Sparkles size={34}/></div><div className="wheel-pointer"/></div>{spinResult && <div className="spin-result">Result: <b>{spinResult}</b></div>}<button className="primary-btn full" disabled={spinning} onClick={spin}>{spinning ? "Spinning..." : "Spin the wheel"} <ChevronRight size={16}/></button><div className="tiny-note">Demo animation only; no cash prize is credited.</div></section></div></>;
}

function Tasks({ checkinClaimed, claimCheckin, setPage }) {
  const tasks = [
    {icon:CalendarCheck,title:"Daily check-in",desc:"Visit the platform and claim today's check-in.",reward:"Daily reward",status:checkinClaimed?"Completed":"Available",action:claimCheckin,disabled:checkinClaimed,button:checkinClaimed?"Completed":"Check in",tone:"green"},
    {icon:Candy,title:"Play Candy Match",desc:"Play a puzzle round and submit an eligible result.",reward:"Based on rules",status:"Available",action:()=>setPage("games"),button:"Play game",tone:"pink"},
    {icon:Pickaxe,title:"Mine virtual gold",desc:"Make progress in the mining mini-game.",reward:"Based on rules",status:"Available",action:()=>setPage("games"),button:"Start mining",tone:"gold"},
    {icon:Users,title:"Invite a friend",desc:"Share your referral link and help a friend join.",reward:"Referral bonus",status:"Available",action:()=>setPage("referrals"),button:"Invite friends",tone:"purple"}
  ];
  return <><PageHeading eyebrow="DAILY MISSIONS" title="Small tasks, steady progress" description="See what's available and keep track of your daily activity."/><div className="task-list">{tasks.map((t,i)=>{const Icon=t.icon;return <div className="task-row" key={i}><div className={`task-icon ${t.tone}`}><Icon size={22}/></div><div className="task-copy"><div className="task-title">{t.title}<span className={`task-status ${t.status==="Completed"?"done":""}`}>{t.status}</span></div><p>{t.desc}</p><span className="task-reward"><Gift size={14}/>{t.reward}</span></div><button className="outline-btn task-action" disabled={t.disabled} onClick={t.action}>{t.button}</button></div>})}</div><div className="policy-note"><ShieldCheck size={18}/><span><b>Fair rewards</b><br/>Task rewards are governed by platform rules, account eligibility, and available reward funding.</span></div></>;
}

function Referrals({ referralLink, referralCount, copy }) {
  return <><PageHeading eyebrow="GROW YOUR CIRCLE" title="Invite friends" description="Share your unique link and track eligible referrals."/><section className="referral-hero"><div><span className="hero-badge"><Users size={13}/> REFERRAL PROGRAM</span><h2>Good things are<br/>better together.</h2><p>Invite friends to join PlayCash. Referral rewards are credited only when the platform's eligibility requirements are met.</p></div><div className="referral-graphic"><div className="person person-one">♙</div><div className="person person-two">♙</div><div className="person person-three">♙</div><div className="heart">✦</div></div></section><div className="stat-grid two"><Stat icon={Users} label="Total referrals" value={referralCount} sub="Accounts linked to your code" color="purple"/><Stat icon={Gift} label="Referral rewards" value="—" sub="See your wallet ledger" color="gold"/></div><section className="panel referral-link-panel"><div className="panel-heading"><div><h3>Your invitation link</h3><p>Copy it and share it with friends.</p></div><span className="panel-icon purple"><Copy size={18}/></span></div><div className="copy-field"><span>{referralLink || "Your link appears after your profile is configured."}</span><button className="primary-btn" onClick={() => copy(referralLink)} disabled={!referralLink}><Copy size={16}/> Copy link</button></div><div className="tiny-note">Never create multiple accounts to earn referral bonuses. Suspicious activity may be reviewed.</div></section></>;
}

function WalletPage({ balance, transactions, withdrawals, setPage }) {
  return <><PageHeading eyebrow="YOUR MONEY SPACE" title="Wallet & activity" description="Review available rewards and recent account activity." action={<button className="primary-btn" onClick={() => setPage("withdraw")}>Request withdrawal <ArrowDownToLine size={16}/></button>}/><section className="wallet-overview"><div><span>AVAILABLE BALANCE</span><strong>{money(balance)}</strong><p>Withdrawable balance is based on the server-side wallet ledger.</p></div><div className="wallet-art"><Wallet size={60}/><Sparkles size={23}/></div></section><div className="wallet-lists"><section className="panel"><div className="panel-heading"><div><h3>Transactions</h3><p>Credits and debits in your wallet.</p></div></div>{transactions.length ? <div className="table-wrap"><table><thead><tr><th>Activity</th><th>Date</th><th>Amount</th></tr></thead><tbody>{transactions.map(tx=><tr key={tx.id}><td>{tx.description || tx.transaction_type}</td><td>{new Date(tx.created_at).toLocaleDateString()}</td><td className={tx.amount_cents>0?"positive":""}>{money(tx.amount_cents/100)}</td></tr>)}</tbody></table></div>:<div className="empty-state"><History size={25}/><b>No transactions yet</b><span>When eligible rewards are credited, they'll appear here.</span></div>}</section><section className="panel"><div className="panel-heading"><div><h3>Withdrawal history</h3><p>Track requests and statuses.</p></div></div>{withdrawals.length ? withdrawals.map(w=><div className="withdrawal-row" key={w.id}><div><b>{money(w.amount_cents/100)}</b><span>{w.payout_method} · {new Date(w.created_at).toLocaleDateString()}</span></div><span className={`status-chip ${w.status}`}>{w.status}</span></div>):<div className="empty-state"><ArrowDownToLine size={25}/><b>No withdrawals yet</b><span>Your withdrawal requests will appear here.</span></div>}</section></div></>;
}

function WithdrawPage({ balance, amount, setAmount, method, setMethod, paymentDetails, setPaymentDetails, submitWithdrawal, withdrawals }) {
  const methods = ["Bank transfer","PayPal","OPay","PalmPay","Cryptocurrency"];
  return <><PageHeading eyebrow="CASH OUT" title="Request a withdrawal" description="Submit a payout request for review. Payment availability depends on your country and provider."/><div className="withdraw-layout"><div><section className="withdraw-balance"><span>AVAILABLE BALANCE</span><strong>{money(balance)}</strong><div><Wallet size={16}/> Minimum withdrawal: $200.00</div></section><section className="panel withdraw-form-panel"><div className="panel-heading"><div><h3>Withdrawal details</h3><p>Review all details carefully before submitting.</p></div><span className="panel-icon green"><ArrowDownToLine size={18}/></span></div><form className="withdraw-form" onSubmit={submitWithdrawal}><label>Amount (USD)<div className="amount-input"><span>$</span><input type="number" min="200" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)} required/><button type="button" onClick={()=>setAmount(String(Math.max(200,balance)))} disabled={balance<200}>Max</button></div></label><div className="quick-amounts">{[200,250,500,1000].map(n=><button type="button" key={n} className={Number(amount)===n?"selected":""} onClick={()=>setAmount(String(n))}>${n}</button>)}</div><label>Payout method<select value={method} onChange={e=>setMethod(e.target.value)}>{methods.map(m=><option key={m}>{m}</option>)}</select></label><label>Payment details<textarea value={paymentDetails} onChange={e=>setPaymentDetails(e.target.value)} placeholder={method==="Bank transfer"?"Account name, bank name, account number, country":method==="PayPal"?"PayPal account email":method==="OPay"||method==="PalmPay"?"Account name and registered phone/account number":"Cryptocurrency network and wallet address"} rows={3} required/></label><div className="withdraw-summary"><div><span>Requested amount</span><b>{money(Number(amount)||0)}</b></div><div><span>Estimated fees</span><b>Confirmed before processing</b></div><div className="summary-total"><span>Minimum required</span><strong>$200.00</strong></div></div><button className="primary-btn full" type="submit" disabled={balance<200||Number(amount)<200}><ArrowDownToLine size={16}/> Submit withdrawal request</button><p className="tiny-note">This submits a request; it does not transfer money automatically. Never enter your password, PIN, or private crypto key.</p></form></section></div><aside className="withdraw-aside"><section className="panel"><span className="panel-icon gold"><ShieldCheck size={19}/></span><h3>How payouts work</h3><ol className="steps"><li><b>Submit request</b><span>Choose a method and enter payout details.</span></li><li><b>Review</b><span>Your request is checked against eligibility and available funds.</span></li><li><b>Processing</b><span>Approved payments are processed through configured providers or an authorized operator.</span></li></ol></section><section className="policy-note"><LockKeyhole size={18}/><span><b>Keep your account safe</b><br/>Only enter the minimum payment details required. Provider support and fees vary by region.</span></section></aside></div><section className="panel history-panel"><div className="panel-heading"><div><h3>Recent requests</h3><p>Current status of your payout requests.</p></div></div>{withdrawals.length?withdrawals.map(w=><div className="withdrawal-row" key={w.id}><div><b>{money(w.amount_cents/100)}</b><span>{w.payout_method} · {new Date(w.created_at).toLocaleDateString()}</span></div><span className={`status-chip ${w.status}`}>{w.status}</span></div>):<div className="empty-state"><Clock3 size={24}/><b>No requests yet</b><span>Requests you submit will appear here.</span></div>}</section></>;
}

function AdminPage({ rows, reload, updateWithdrawal, isAdmin }) {
  if (!isAdmin) return <><PageHeading eyebrow="RESTRICTED AREA" title="Admin panel" description="Administrator access is restricted."/><div className="policy-note"><ShieldCheck size={18}/><span>Only accounts explicitly granted admin permissions in the database can access this area.</span></div></>;
  return <><PageHeading eyebrow="PLATFORM MANAGEMENT" title="Admin panel" description="Review withdrawal requests and manage payout workflow." action={<button className="outline-btn" onClick={reload}>Refresh <RotateCw size={15}/></button>}/><section className="panel"><div className="panel-heading"><div><h3>Withdrawal requests</h3><p>Review requests before making any payment.</p></div></div>{rows.length? <div className="table-wrap"><table><thead><tr><th>Request</th><th>Method</th><th>Status</th><th>Created</th><th>Action</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{money(r.amount_cents/100)}</td><td>{r.payout_method}</td><td><span className={`status-chip ${r.status}`}>{r.status}</span></td><td>{new Date(r.created_at).toLocaleDateString()}</td><td><div className="admin-actions"><button onClick={()=>updateWithdrawal(r.id,"approved")} disabled={r.status!=="pending"}>Approve</button><button onClick={()=>updateWithdrawal(r.id,"rejected")} disabled={!["pending","under_review"].includes(r.status)}>Reject</button><button onClick={()=>updateWithdrawal(r.id,"paid")} disabled={r.status!=="processing"}>Mark paid</button></div></td></tr>)}</tbody></table></div>:<div className="empty-state"><ArrowDownToLine size={25}/><b>No requests found</b><span>New withdrawal requests will appear here.</span></div>}</section><div className="policy-note"><ShieldCheck size={18}/><span><b>Manual payment workflow</b><br/>Approving a request is not proof that a payment was sent. Mark it paid only after confirming the transfer through the relevant payment provider.</span></div></>;
}

export default App;
